package com.example.recado.network

import kotlinx.serialization.Serializable

@Serializable
data class Token(
    val token: String,
)